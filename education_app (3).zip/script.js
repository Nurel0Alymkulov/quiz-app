const questions = {
  math: [
    {
      q: "Сколько будет 7 × 8?",
      options: ["54", "56", "58", "48"],
      answer: 1
    },
    {
      q: "Чему равен корень из 81?",
      options: ["8", "9", "7", "10"],
      answer: 1
    },
    {
      q: "Сколько будет 27+39?",
      options: ["66", "65", "70", "67"],
      answer: 0
    },
    {
      q: "Сколько будет 2+2*2?",
      options: ["4", "8", "2", "6"],
      answer: 3
    }
  ],
  english: [
    {
      q: "What is the past tense of 'go'?",
      options: ["goed", "gone", "went", "go"],
      answer: 2
    },
    {
      q: "Translate: 'Книга' на английском?",
      options: ["Pen", "Book", "Table", "Copybook"],
      answer: 1
    },
    {
      q: "What is the past participle tense of 'pay'?",
      options: ["Pay", "Pen", "Paid", "Buy"],
      answer: 2
    },
    {
      q: "Translate: 'Школа' на английском?",
      options: ["House", "Market", "School", "Hospital"],
      answer: 2
    }
  ]
};

function showSubject(subject) {
  const quizArea = document.getElementById("quiz-area");
  quizArea.innerHTML = "";

  questions[subject].forEach((item) => {
    const card = document.createElement("div");
    card.className = "card";

    const questionText = document.createElement("h3");
    questionText.textContent = item.q;
    card.appendChild(questionText);

    item.options.forEach((optionText, index) => {
      const button = document.createElement("button");
      button.textContent = optionText;

      button.addEventListener("click", () => {
        const allButtons = card.querySelectorAll("button");
        allButtons.forEach(btn => btn.disabled = true);

        if (index === item.answer) {
          button.classList.add("correct");
        } else {
          button.classList.add("wrong");
          allButtons[item.answer].classList.add("correct");
        }
      });

      card.appendChild(button);
    });

    quizArea.appendChild(card);
  });
}
