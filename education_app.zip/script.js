const questions = {
  math: [
    {
      q: "Сколько будет 7 × 8?",
      options: ["54", "56", "58", "48"],
      answer: 1 // 56
    },
    {
      q: "Чему равен корень из 81?",
      options: ["8", "9", "7", "10"],
      answer: 1 // 9
    },
    {
      q: "Сколько будет 27+39?",
      options: ["66", "65", "70", "67"],
      answer: 0 // 66
    },
    {
      q: "Сколько будет 2+2*2?",
      options: ["4", "8", "2", "6"],
      answer: 3 // 6          
    }
  ],
  english: [
    {
      q: "What is the past tense of 'go'?",
      options: ["goed", "gone", "went", "go"],
      answer: 2 // went
    },
    {
      q: "Translate: 'Книга' на английском?",
      options: ["Pen", "Book", "Table", "Copybook"],
      answer: 1 // Book 
    },
    {
      q: "What is the past participle tense of 'pay'?",
      options: ["Pay", "Pen", "Paid", "Buy"],
      answer: 2 // Paid
    },
    {
      q: "Translate: 'Школа' на анлийском?",
      options: ["House", "Market", "School", "Hospital"],
      answer: 2 // School
    }
  ]
};

function showSubject(subject) {
  const quizArea = document.getElementById("quiz-area");
  quizArea.innerHTML = ""; // очищаем область вопросов

  questions[subject].forEach((item) => {
    const card = document.createElement("div");
    card.className = "card";

    const questionText = document.createElement("h3");
    questionText.textContent = item.q;
    card.appendChild(questionText);

    item.options.forEach((optionText, index) => {
      const button = document.createElement("button");
      button.textContent = optionText;

      button.addEventListener("click", () => {
        // Отключаем все кнопки после выбора
        const allButtons = card.querySelectorAll("button");
        allButtons.forEach(btn => btn.disabled = true);

        // Проверка правильности
        if (index === item.answer) {
          button.classList.add("correct");
        } else {
          button.classList.add("wrong");
          // Подсветим правильный вариант:
          allButtons[item.answer].classList.add("correct");
        }
      });

      card.appendChild(button);
    });

    quizArea.appendChild(card);
  });
}
